=====
Usage
=====

To use zenq in a project::

    import zenq
