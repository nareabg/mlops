#URI string that specifies the location and credentials to connect to a PostgreSQL database
db_uri = 'postgresql://master:pass@localhost/GLOBBING'

# username - master
# password - pass
# database name - GLOBBING

