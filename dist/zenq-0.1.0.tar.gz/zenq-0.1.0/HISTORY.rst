=======
History
=======

0.1.0 (2023-05-04)
------------------

* First release on PyPI.
